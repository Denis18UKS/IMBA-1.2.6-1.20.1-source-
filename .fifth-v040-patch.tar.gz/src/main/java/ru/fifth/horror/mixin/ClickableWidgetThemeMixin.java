package ru.fifth.horror.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.fifth.horror.client.gui.HorrorButton;
import ru.fifth.horror.client.gui.HorrorTheme;

/** A final overlay skins even vanilla button subclasses that override renderButton themselves. */
@Mixin(ClickableWidget.class)
public abstract class ClickableWidgetThemeMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void fifth$skinEveryPressable(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        ClickableWidget self = (ClickableWidget)(Object)this;
        if (self instanceof PressableWidget && !(self instanceof HorrorButton)) HorrorTheme.overlayVanillaButton(context, self);
    }
}
