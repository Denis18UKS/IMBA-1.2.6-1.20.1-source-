package ru.fifth.horror.client;

import com.google.gson.Gson;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.TypedActionResult;
import ru.fifth.horror.FifthMod;
import ru.fifth.horror.client.gui.*;
import ru.fifth.horror.cutscene.CutsceneDefinition;
import ru.fifth.horror.network.FifthNetworking;

public final class FifthClient implements ClientModInitializer {
    private static final Gson GSON=new Gson();
    @Override public void onInitializeClient(){
        EntityRendererRegistry.register(FifthMod.DIRECTOR_NPC, DirectorNpcRenderer::new);
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(AnimationCatalog.INSTANCE);
        ClientPlayNetworking.registerGlobalReceiver(FifthNetworking.OPEN_COMPUTER,(client,handler,buf,responseSender)->{var pos=buf.readBlockPos();String name=buf.readString(128),script=buf.readString(1_000_000);client.execute(()->client.setScreen(new ScriptComputerScreen(pos,name,script)));});
        ClientPlayNetworking.registerGlobalReceiver(FifthNetworking.CUTSCENE_PAYLOAD,(client,handler,buf,responseSender)->{String json=buf.readString(1_000_000);client.execute(()->{try{CutscenePlayback.start(GSON.fromJson(json,CutsceneDefinition.class));client.setScreen(null);}catch(Exception ignored){}});});
        ClientPlayNetworking.registerGlobalReceiver(FifthNetworking.NPC_LIBRARY_PAYLOAD,(client,handler,buf,responseSender)->{
            int count=Math.min(2048,buf.readVarInt());
            java.util.List<ScriptComputerScreen.NpcInfo> rows=new java.util.ArrayList<>(count);
            for(int i=0;i<count;i++) rows.add(new ScriptComputerScreen.NpcInfo(buf.readUuid(),buf.readString(128),buf.readString(256),buf.readBoolean(),buf.readString(512),buf.readVarInt(),buf.readString(256)));
            client.execute(()->{if(client.currentScreen instanceof ScriptComputerScreen screen)screen.updateNpcLibrary(rows);});
        });

        UseItemCallback.EVENT.register((player,world,hand)->{
            if(!world.isClient)return TypedActionResult.pass(player.getStackInHand(hand));
            var stack=player.getStackInHand(hand);MinecraftClient c=MinecraftClient.getInstance();
            if(stack.isOf(FifthMod.NPC_CREATOR)){c.setScreen(new NpcCreatorScreen(c.currentScreen,-1,null));return TypedActionResult.success(stack);}
            if(stack.isOf(FifthMod.CAMERA_TOOL)){c.setScreen(new CameraEditorScreen(c.currentScreen));return TypedActionResult.success(stack);}
            // Air-click always opens the layer editor. Coordinates may be selected before OR after opening it.
            if(stack.isOf(FifthMod.BUILD_LAYER_TOOL)){c.setScreen(new BuildLayerScreen(c.currentScreen,stack.copy()));return TypedActionResult.success(stack);}
            return TypedActionResult.pass(stack);
        });

        // No visible developer key binding: the studio is intentionally reachable only from the secret elevator hotspot.
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            MenuMusicController.tick(client);
            CutscenePlayback.tick();
            if(CutscenePlayback.lockInput()&&client.player!=null&&client.player.input!=null){client.player.input.movementForward=0;client.player.input.movementSideways=0;client.player.input.jumping=false;client.player.input.sneaking=false;}
        });
    }
}
